package com.example.androidwarmup;

/**
 * Created by taharushain on 3/7/17.
 */

public class util {

    public static final String PREF_KEY = "androidwarmup";
    public static final String LOGIN_KEY = "androidwarmup_login";
}
